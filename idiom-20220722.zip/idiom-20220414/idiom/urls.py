from idiom import views
from django.urls import path

urlpatterns = [
    path('', views.idiom_form),
    path('idiom_form', views.idiom_form),
    path('query_results', views.query_results),
    path('list_idioms_of_sense/<str:sense>', views.list_idioms_of_sense)
]

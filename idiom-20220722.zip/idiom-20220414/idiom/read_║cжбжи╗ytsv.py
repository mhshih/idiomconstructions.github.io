import sys, csv

filename = sys.argv[1]#'構式成語-新格式(三人版).xlsx - 進度表_王雅筠.tsv'
#rows = reader(open('構式成語-新格式(三人版).xlsx - 進度表_王雅筠.tsv'), delimiter='\t')
rows = csv.reader(open(filename), delimiter='\t')

header = next(rows)

from collections import OrderedDict
idioms = [OrderedDict(list(zip(header, row))) for row in rows]

for idiom in idioms:
    print(idiom)

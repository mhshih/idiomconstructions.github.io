import csv
#rows = csv.reader(open('構式成語-新格式(三人版).xlsx - 進度表_all.tsv'), delimiter="\t")#'構式成語-新格式(三人版)_王雅筠.tsv',, encoding='UTF-8'), delimiter='\t')
rows = csv.reader(open('構式成語-新格式(三人版) - all.tsv', encoding='UTF-8'), delimiter="\t")#'構式成語-新格式(三人版)_王雅筠.tsv'), delimiter='\t')
header = next(rows)

from collections import OrderedDict
idioms = [OrderedDict(list(zip(header, row))) for row in rows]

f = open('構式成語-新格式(三人版).xlsx - 近義成語參照表.tsv', encoding='UTF-8')
header = next(f)
synonyms = f.readline().split()


from django.shortcuts import render
def idiom_form(request):
    return render(request, 'idiom_form.htm', {})

def search_txt(query, filename='Gigaword_concordancer-alldisk3cna2-sentences.txt'):
    results=[]
    for line in open(filename, encoding='UTF-8'):
        if query in line:
            results.append(line)
    return results

from django.http import HttpResponse
def query_results(request):
    query = request.GET['query']
    for idiom in idioms:
        if query in idiom['成語'] or query in idiom['構式']:
            sentences=[]#search_txt(query) 先關掉比較快，之後改成別的方式比較快。
            if idiom['成語'] in synonyms:
                return render(request, 'query_results.htm', {'idiom': idiom, "synonyms": synonyms})
            return render(request, 'query_results.htm', {'idiom': idiom})#, 'CNA': len(sentences)})
    return HttpResponse('抱歉，目前未收錄本成語。')

from django.http import HttpResponse
def list_idioms_of_sense(request, sense):
    results = []
    for idiom in idioms:
        if idiom['構式義'] == sense:
            results.append(idiom)
    return render(request, 'list_idioms_of_sense.htm', {'idioms': results})

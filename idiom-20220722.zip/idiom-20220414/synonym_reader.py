from sys import argv
filename = argv[1] #'構式成語-新格式(三人版).xlsx - 近義成語參照表.tsv'

f = open(filename)
header = next(f)

for row in f: 
    print(row.split())

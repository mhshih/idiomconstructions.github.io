from sys import argv
from csv import reader

filename = argv[1] #構式成語語...-統整.csv 共22欄。

cr = reader(open(filename), delimiter='\t')
header = next(cr)

for columns in [list(zip(header, row)) for row in cr]: # Restructure to like named tuples.
    QIE = columns[0]
    成語 = QIE[1]
    try:
        if 成語[0] == '一' and 成語[2] in '一二千':
            print(成語)
    except:
        pass
